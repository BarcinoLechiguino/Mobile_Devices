package com.example.userlist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
